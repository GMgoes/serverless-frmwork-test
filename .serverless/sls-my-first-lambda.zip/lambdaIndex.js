exports.handler = async function (event, context) {
  return {
    statusCode: 200,
    body: JSON.stringify({
      message: "Essa mensagem foi produzida por uma Lambda AWS",
    }),
  };
};
